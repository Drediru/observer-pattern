import java.util.List;

//Clase Observador
public interface Observer {
    void update(List<Pedido> pedidos);
}
